package com.group3.webdoctruyen;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebdoctruyenApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebdoctruyenApplication.class, args);
	}

}
