package com.group3.webdoctruyen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebdoctruyenApplicationTests {

	@Test
	void contextLoads() {
	}

}
